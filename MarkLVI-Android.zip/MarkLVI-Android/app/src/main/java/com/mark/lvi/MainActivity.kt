package com.mark.lvi

import android.Manifest
import android.app.Activity
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import kotlin.concurrent.thread

private const val MODEL = "gemini-2.5-flash"

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var talk: Button
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = JSONArray()
    private val h = Handler(Looper.getMainLooper())
    private val wakeWords = listOf("jarvis", "jervis")
    private lateinit var wakeBtn: Button
    private var wakeOn = false
    private var visible = false
    private var mode = 0 // 0 idle, 1 waiting for wake word, 2 listening for a command
    private var afterSpeech: (() -> Unit)? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("mark", MODE_PRIVATE)
        tts = TextToSpeech(this) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { done() }
                override fun onError(id: String?) { done() }
            })
        }
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        log = TextView(this).apply { textSize = 16f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply {
            hint = "Type a message, or tap Talk"
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine()
        }
        input.setOnEditorActionListener { _, _, _ ->
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); ask(t) }
            true
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        talk = Button(this).apply { text = "Talk"; setOnClickListener { listen() } }
        root.addView(talk, LinearLayout.LayoutParams(-1, (64 * d).toInt()))
        val keyBtn = Button(this).apply { text = "API key"; setOnClickListener { keyDialog() } }
        root.addView(keyBtn, LinearLayout.LayoutParams(-1, -2))
        wakeBtn = Button(this).apply {
            setOnClickListener {
                wakeOn = !wakeOn
                applyWake()
                if (wakeOn) resume() else { mode = 0; recognizer?.cancel(); mute(false) }
            }
        }
        root.addView(wakeBtn, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        wakeOn = prefs.getBoolean("wake", false)
        applyWake()
        add("MARK LVI online. Tap Talk, or turn on the wake word and say 'Hey Jarvis'.")
    }

    override fun onDestroy() {
        mute(false); recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }

    override fun onResume() { super.onResume(); visible = true; resume() }

    override fun onPause() {
        visible = false; mode = 0; h.removeCallbacksAndMessages(null)
        recognizer?.cancel(); mute(false); super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) { if (wakeOn) resume() else startRec(true) }
        else { wakeOn = false; applyWake() }
    }

    private fun add(s: String) = runOnUiThread {
        log.append(s + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun say(s: String, then: (() -> Unit)? = null) = runOnUiThread {
        log.append("Mark: $s\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        mode = 0; recognizer?.cancel(); mute(false)
        afterSpeech = then
        if (tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "m") != TextToSpeech.SUCCESS) done()
    }

    private fun done() = h.post {
        val f = afterSpeech; afterSpeech = null
        if (f != null) f() else resume()
    }

    private fun mute(on: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try { am.adjustStreamVolume(st, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) { }
        }
    }

    private fun applyWake() {
        wakeBtn.text = if (wakeOn) "Wake word: ON (say \"Hey Jarvis\")" else "Wake word: OFF"
        prefs.edit().putBoolean("wake", wakeOn).apply()
        if (wakeOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun keyDialog() {
        val e = EditText(this).apply { hint = "Gemini API key"; setText(prefs.getString("key", "")) }
        AlertDialog.Builder(this)
            .setTitle("Gemini API key (aistudio.google.com/apikey)")
            .setView(e)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString("key", e.text.toString().trim()).apply() }
            .show()
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun listen() = startRec(true)

    private fun resume() { if (wakeOn && visible && mode == 0) startRec(false) }

    private fun restartWake(ms: Long) { mode = 0; h.postDelayed({ resume() }, ms) }

    private fun wakeHit(r: Bundle?): String? {
        for (t in r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()) {
            val l = t.lowercase()
            for (w in wakeWords) {
                val i = l.indexOf(w)
                if (i >= 0) return l.substring(i + w.length).trim(' ', ',', '.', '!', '?')
            }
        }
        return null
    }

    private fun startRec(command: Boolean) {
        if (!hasMic()) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            wakeOn = false; applyWake(); say("Speech recognition isn't available on this device."); return
        }
        recognizer?.destroy()
        mode = if (command) 2 else 1
        mute(true)
        if (command) talk.text = "Listening..."
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    if (mode == 1) {
                        val rest = wakeHit(r)
                        if (rest == null) { restartWake(150); return }
                        mode = 0
                        if (rest.length > 1) ask(rest) else say("Yes?") { startRec(true) }
                    } else if (mode == 2) {
                        mode = 0; mute(false); talk.text = "Talk"
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (t != null) ask(t) else restartWake(250)
                    }
                }
                override fun onError(e: Int) {
                    if (mode == 0) return
                    val was = mode
                    mode = 0; mute(false); talk.text = "Talk"
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { wakeOn = false; applyWake(); return }
                    if (was == 2) add("Didn't catch that.")
                    restartWake(if (e == 6 || e == 7) 150L else 1500L)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }

    private fun ask(text: String) {
        add("You: $text")
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) { keyDialog(); restartWake(500); return }
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        thread {
            try {
                var reply = ""
                for (turn in 0 until 5) {
                    val res = gemini(key)
                    val cands = res.optJSONArray("candidates")
                    if (cands == null || cands.length() == 0) throw Exception("No reply (blocked or empty)")
                    val content = cands.getJSONObject(0).getJSONObject("content")
                    history.put(content)
                    val parts = content.optJSONArray("parts") ?: JSONArray()
                    val results = JSONArray()
                    for (j in 0 until parts.length()) {
                        val p = parts.getJSONObject(j)
                        if (p.has("text")) reply += p.getString("text")
                        if (p.has("functionCall")) {
                            val fc = p.getJSONObject("functionCall")
                            val out = runTool(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
                            add("[tool] ${fc.getString("name")}: $out")
                            results.put(JSONObject().put("functionResponse", JSONObject()
                                .put("name", fc.getString("name"))
                                .put("response", JSONObject().put("result", out))))
                        }
                    }
                    if (results.length() == 0) break
                    history.put(JSONObject().put("role", "user").put("parts", results))
                }
                say(reply.ifBlank { "Done." })
            } catch (e: Exception) { add("Error: ${e.message}"); h.post { resume() } }
        }
    }

    private fun system() = "You are Mark LVI, a concise voice assistant on an Android phone. " +
        "Reply in the user's language in one or two short sentences. Use tools to act. " +
        "Never claim an action succeeded unless the tool result says so; if a result says " +
        "'not verified' or the user must press a button, say exactly that. " +
        "Current time: ${Date()}. Known facts about the user:\n${memory()}"

    private fun memory() = prefs.getString("mem", "") ?: ""

    private fun gemini(key: String): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", history)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools())))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("Gemini ${c.responseCode}: ${txt.take(200)}")
        return JSONObject(txt)
    }

    private fun fn(n: String, d: String, vararg p: Pair<String, String>) =
        JSONObject().put("name", n).put("description", d).also { o ->
            if (p.isNotEmpty()) o.put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().also { props -> p.forEach { (k, t) -> props.put(k, JSONObject().put("type", t)) } })
                .put("required", JSONArray(p.map { it.first })))
        }

    private fun tools() = JSONArray()
        .put(fn("set_alarm", "Set an alarm at a 24-hour time", "hour" to "INTEGER", "minute" to "INTEGER", "label" to "STRING"))
        .put(fn("set_timer", "Start a countdown timer", "seconds" to "INTEGER", "label" to "STRING"))
        .put(fn("open_app", "Open an installed app by name", "name" to "STRING"))
        .put(fn("call", "Open the dialer with a number; the user presses call", "number" to "STRING"))
        .put(fn("send_sms", "Draft an SMS; the user presses send", "number" to "STRING", "message" to "STRING"))
        .put(fn("web_search", "Search the web in the browser", "query" to "STRING"))
        .put(fn("remember", "Save a fact about the user for later", "fact" to "STRING"))

    private fun go(i: Intent, ok: String): String { startActivity(i); return ok }

    private fun runTool(name: String, a: JSONObject): String = try {
        when (name) {
            "set_alarm" -> go(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Mark"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true), "Alarm request handed to the clock app. Not verified.")
            "set_timer" -> go(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Timer"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true), "Timer request handed to the clock app. Not verified.")
            "open_app" -> {
                val n = a.getString("name").lowercase()
                val pm = packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
                val launch = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                if (hit == null || launch == null) "No installed app matches '$n'."
                else go(launch, "Launch of ${hit.loadLabel(pm)} requested. Not verified.")
            }
            "call" -> go(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", a.getString("number"), null)),
                "Dialer opened. The user must press call.")
            "send_sms" -> go(Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", a.getString("number"), null))
                .putExtra("sms_body", a.getString("message")), "Message drafted. The user must press send.")
            "web_search" -> go(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))), "Search opened in the browser.")
            "remember" -> {
                val all = (memory() + "\n" + a.getString("fact")).lines().filter { it.isNotBlank() }.takeLast(50)
                prefs.edit().putString("mem", all.joinToString("\n")).apply()
                "Saved."
            }
            else -> "Unknown tool."
        }
    } catch (e: Exception) { "Failed: ${e.message}" }
}
