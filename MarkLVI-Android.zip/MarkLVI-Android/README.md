# Mark LVI for Android

Voice assistant (Gemini) with tools: alarms, timers, open apps, dial, draft SMS, web search, memory.
Calls and SMS only open the dialer/composer; you press the final button.

## Get the APK
**A. No PC (GitHub):** create a GitHub repo, upload this folder's contents, open the Actions tab,
run "Build APK", download the `MarkLVI-apk` artifact, unzip, open app-debug.apk on your phone
(allow "install unknown apps" when asked).

**B. Android Studio:** open this folder, Build > Build APK(s), copy app-debug.apk to your phone.

## First run
Tap "API key", paste a free key from https://aistudio.google.com/apikey, then tap Talk.

## Wake word
Tap "Wake word: OFF" to turn it on, then say "Hey Jarvis" (or "Hey Jarvis, set a timer for 5 minutes").
It uses the phone's speech recognizer, so it only listens while the app is open (the screen is kept on),
and it mutes media/system volume while listening to hide the recognizer's restart beeps.
